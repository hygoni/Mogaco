/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyeyoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/07/07 02:06:54 by hyeyoo            #+#    #+#             */
/*   Updated: 2020/07/07 02:42:57 by hyeyoo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

extern int ft_strlen(char *str);
extern char* ft_strcpy(char *dst, char *src);

int		main(void)
{
	int len = ft_strlen("1234");
	printf("%d\n", len);

	char buf[100];
	ft_strcpy(buf, "hello, world dude!");
	printf("%s\n", buf);
}
