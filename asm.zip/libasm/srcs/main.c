/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyeyoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/07/07 02:06:54 by hyeyoo            #+#    #+#             */
/*   Updated: 2020/07/07 05:20:07 by hyeyoo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

extern int errno;
extern int ft_strlen(char *str);
extern char* ft_strcpy(char *dst, char *src);
extern int	ft_strcmp(char *s1, char *s2);
extern int 	ft_write(int fd, char *buf, size_t size);
extern int 	ft_read(int fd, char *buf, size_t size);
extern char *ft_strdup(char *ft_strdup);

int		main(void)
{
	printf("==== ft_strlen ====\n");
	int len = ft_strlen("1234");
	printf("length of 1234 : %d\n", len);

	char buf[100];
	printf("==== ft_strcpy ====\n");
	ft_strcpy(buf, "hello, world dude!");
	printf("%s\n", buf);

	printf("==== ft_strcmp ====\n");
	int ret = ft_strcmp("abc", "abcd");
	printf("abc and abcd : %d\n", ret);
	ret = ft_strcmp("abcd", "abcd");
	printf("abcd and abcd : %d\n", ret);
	ret = ft_strcmp("abcd", "abc");
	printf("abcd and abc : %d\n", ret);
	
	printf("==== ft_write ====");
   	ft_write(1, "hello!\n", 7);
	printf("errno : %d\n", errno);

	printf("==== ft_write (wrong fd) ====");
   	ft_write(0xff, "hello!\n", 7);
	printf("errno : %d\n", errno);

	memset(buf, 0, 100);
	printf("==== ft_read ====\n");
	ft_read(0, buf, 10);
	printf("%s\n", buf);


	memset(buf, 0, 100);
	printf("==== ft_read (wrong fd) ====\n");
	ft_read(0xfffff, buf, 10);
	printf("errno : %d\n", errno);

	printf("==== ft_strdup ====\n");
	char *copied = ft_strdup("hello, world!");
	printf("%s\n", copied);
	free(copied);
}
